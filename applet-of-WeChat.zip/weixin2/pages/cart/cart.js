// pages/cart/cart.js
Page({
    gototest2(){
        wx.navigateTo({
          url: '/pages/test2/test2',
        })
    }
})