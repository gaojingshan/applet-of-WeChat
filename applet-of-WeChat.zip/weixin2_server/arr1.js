module.exports = [
  {
    c: '牛排',
    pic:
      'https://img10.360buyimg.com/jdcms/s360x360_jfs/t1/2484/16/1209/304097/5b93f0f0Ec5d0df70/8a440e8db28fa2a2.jpg',
  },
  {
    c: '肉卷',
    pic:
      'https://img12.360buyimg.com/jdcms/s360x360_jfs/t7681/148/2154394350/231974/f976acac/59a8ce05N33517d24.jpg',
  },
  {
    c: '皮蛋',
    pic:
      'https://img13.360buyimg.com/jdcms/s360x360_jfs/t1/22331/40/5299/134413/5c3c2469Ee370283f/be5bdbdf75436f98.jpg',
  },
  {
    c: '虾仁',
    pic:
      'https://img11.360buyimg.com/jdcms/s360x360_jfs/t28393/4/16897789/142439/f4cb43b1/5be55452N745f1ebd.jpg',
  },
  {
    c: '海鲜',
    pic:
      'https://img11.360buyimg.com/jdcms/s360x360_jfs/t1/28110/6/1074/508253/5c0f789bEce39f81c/75cc83855bdebf52.jpg',
  },
  {
    c: '海参',
    pic:
      'https://img10.360buyimg.com/jdcms/s360x360_jfs/t3427/271/37998537/366726/cf2ad41c/57fca74fN9f0104f7.jpg',
  },
  {
    c: '奇异果',
    pic:
      'https://img12.360buyimg.com/jdcms/s360x360_jfs/t23797/101/1565294837/354416/d46747be/5b6299fdNa2588a6a.jpg',
  },
  {
    c: '百香果',
    pic:
      'https://img10.360buyimg.com/jdcms/s360x360_jfs/t1/2484/16/1209/304097/5b93f0f0Ec5d0df70/8a440e8db28fa2a2.jpg',
  },
  {
    c: '肉',
    pic:
      'https://img14.360buyimg.com/jdcms/s360x360_jfs/t18910/185/1403659361/253704/ece62066/5ac74859Nd2ba4167.jpg',
  },
  {
    c: '大虾',
    pic:
      'https://img14.360buyimg.com/jdcms/s360x360_jfs/t7288/146/4614105121/422479/caa23892/5bc3f435Nd47de501.jpg',
  },
];
