module.exports = [
  {
    c: '茶具',
    pic:
      'https://img10.360buyimg.com/jdcms/s360x360_jfs/t3565/206/111987568/733422/401e8d9b/57ff32ebN97dc3d5f.jpg',
  },
  {
    c: '锅',
    pic:
      'https://img11.360buyimg.com/jdcms/s360x360_jfs/t24436/63/247118756/137174/a1842057/5b29fa20Naa0f1aa2.jpg',
  },
  {
    c: '刀',
    pic:
      'https://img12.360buyimg.com/jdcms/s360x360_jfs/t3199/118/1654162119/48261/6d76b54b/57d0e31cN7eb33e37.jpg',
  },
  {
    c: '保鲜盒',
    pic:
      'https://img13.360buyimg.com/jdcms/s360x360_jfs/t24301/48/544196572/174622/ae3f83ac/5b34ba9aN3ba6568f.jpg',
  },
  {
    c: '饭盒',
    pic:
      'https://img14.360buyimg.com/jdcms/s360x360_jfs/t19468/38/784715236/213259/b5a9885b/5aa74214N7ad57a2b.jpg',
  },
  {
    c: '刀组',
    pic:
      'https://img10.360buyimg.com/jdcms/g16/M00/01/07/rBEbRVNrJScIAAAAAAEkuI5nWmsAAAPfgDIQl0AASTQ615.jpg',
  },
  {
    c: '健康锅',
    pic:
      'https://img11.360buyimg.com/jdcms/s360x360_jfs/t23674/208/1809120005/123265/df1adc/5b6aaddfN054c1f9a.jpg',
  },
  {
    c: '烧水壶',
    pic:
      'https://img12.360buyimg.com/jdcms/s360x360_jfs/t21163/42/871998181/184990/ac506040/5b19d6beNa46f1536.jpg',
  },
  {
    c: '茶几',
    pic:
      'https://img13.360buyimg.com/jdcms/s360x360_jfs/t11575/362/826686215/200998/e68ab5d4/59f9408dN2a7788c0.jpg',
  },
  {
    c: '锅盆',
    pic:
      'https://img14.360buyimg.com/jdcms/s360x360_jfs/t21532/296/1471176942/152767/f2bdee7c/5b29fa54N4a45f638.jpg',
  },
];
